

#define CAPTURE_NUM 30

#define BLUE Scalar(255, 100, 60)
#define GREEN Scalar(70, 230, 70)
#define RED Scalar(70, 70, 255)
#define AMBER Scalar(0, 194, 255)
#define INSTRUCT Scalar(255, 150, 50)
#define BLACK Scalar(0,0,0)
#define WHITE Scalar(200, 200, 200)

#define MIN_FACE_SIZE 70
#define MAX_FACE_SIZE 300

#define CONFIDENCE_THRESH 80
